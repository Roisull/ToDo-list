package com.mobile.todolist

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    private lateinit var todoAdapter: TodoAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        todoAdapter = TodoAdapter(mutableListOf())

/* memanggil id RecycleView untuk memuat adapter dari todo */
        rvTodoItems.adapter = todoAdapter

/* memanggil id RecycleView untuk memuat Layout manajer dari todo */
        rvTodoItems.layoutManager = LinearLayoutManager(this)

//        memanggil onClickButton untuk menambah todo
        btnAddTodo.setOnClickListener{
            val todoTitle = etTodoTitle.text.toString()
            if (todoTitle.isNotEmpty()){
                val todo = Todo(todoTitle)
                todoAdapter.addTodo(todo)
                etTodoTitle.text.clear()
            }
        }

//        memanggil onClickButton untuk menghapus todo yang sudah selesai
        btnDeleteDoneTodo.setOnClickListener{
            todoAdapter.deleleteDoneTodos()
        }

    }
}